-- WEEK 2: SQL FOR DATA ANALYSIS
-- Project: E-Commerce Sales Analysis
-- SQL Dialect: MySQL 8.0+

CREATE DATABASE IF NOT EXISTS week2_sql_analysis;
USE week2_sql_analysis;

-- =========================================================
-- 1. CREATE TABLES
-- =========================================================

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(50),
    country VARCHAR(50),
    signup_date DATE
);

CREATE TABLE categories (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category_id INT,
    unit_price DECIMAL(10,2),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    status VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- =========================================================
-- 2. INSERT SAMPLE DATA
-- =========================================================

INSERT INTO customers VALUES
(1, 'Aarav Sharma', 'Hyderabad', 'India', '2025-01-10'),
(2, 'Ananya Reddy', 'Bengaluru', 'India', '2025-01-18'),
(3, 'Rahul Kumar', 'Chennai', 'India', '2025-02-02'),
(4, 'Priya Nair', 'Mumbai', 'India', '2025-02-15'),
(5, 'Vikram Singh', 'Delhi', 'India', '2025-03-01'),
(6, 'Sneha Rao', 'Pune', 'India', '2025-03-12'),
(7, 'Kiran Patel', 'Ahmedabad', 'India', '2025-03-20'),
(8, 'Meera Iyer', 'Kochi', 'India', '2025-04-05');

INSERT INTO categories VALUES
(1, 'Electronics'),
(2, 'Accessories'),
(3, 'Home Appliances'),
(4, 'Office');

INSERT INTO products VALUES
(101, 'Laptop', 1, 65000.00),
(102, 'Smartphone', 1, 30000.00),
(103, 'Headphones', 2, 2500.00),
(104, 'Wireless Mouse', 2, 1200.00),
(105, 'Coffee Maker', 3, 4500.00),
(106, 'Air Purifier', 3, 9000.00),
(107, 'Office Chair', 4, 8500.00),
(108, 'Keyboard', 4, 1800.00);

INSERT INTO orders VALUES
(1001, 1, '2025-05-01', 'Completed'),
(1002, 2, '2025-05-03', 'Completed'),
(1003, 3, '2025-05-05', 'Completed'),
(1004, 1, '2025-05-10', 'Completed'),
(1005, 4, '2025-05-12', 'Completed'),
(1006, 5, '2025-05-15', 'Cancelled'),
(1007, 6, '2025-05-18', 'Completed'),
(1008, 7, '2025-05-20', 'Completed'),
(1009, 2, '2025-05-22', 'Completed'),
(1010, 8, '2025-05-25', 'Completed'),
(1011, 5, '2025-05-27', 'Completed'),
(1012, 3, '2025-05-30', 'Completed');

INSERT INTO order_items VALUES
(1, 1001, 101, 1),
(2, 1001, 103, 2),
(3, 1002, 102, 1),
(4, 1002, 104, 2),
(5, 1003, 105, 1),
(6, 1003, 108, 2),
(7, 1004, 106, 1),
(8, 1004, 104, 1),
(9, 1005, 107, 2),
(10, 1005, 108, 1),
(11, 1006, 101, 1),
(12, 1007, 103, 3),
(13, 1007, 105, 1),
(14, 1008, 102, 1),
(15, 1008, 107, 1),
(16, 1009, 101, 1),
(17, 1009, 104, 1),
(18, 1010, 106, 2),
(19, 1010, 103, 1),
(20, 1011, 105, 2),
(21, 1011, 108, 1),
(22, 1012, 102, 1),
(23, 1012, 103, 2);

-- =========================================================
-- 3. BASIC SELECT / WHERE
-- =========================================================

-- Q1. Display all customers.
SELECT * FROM customers;

-- Q2. Display customers from Hyderabad.
SELECT *
FROM customers
WHERE city = 'Hyderabad';

-- Q3. Display products costing more than 5,000.
SELECT product_id, product_name, unit_price
FROM products
WHERE unit_price > 5000
ORDER BY unit_price DESC;

-- =========================================================
-- 4. AGGREGATIONS: SUM, AVG, COUNT
-- =========================================================

-- Q4. Calculate total revenue from completed orders.
SELECT
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS total_revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Completed';

-- Q5. Calculate average completed order value.
SELECT
    ROUND(AVG(order_total), 2) AS average_order_value
FROM (
    SELECT
        o.order_id,
        SUM(oi.quantity * p.unit_price) AS order_total
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    WHERE o.status = 'Completed'
    GROUP BY o.order_id
) AS order_totals;

-- Q6. Count completed orders.
SELECT COUNT(*) AS completed_orders
FROM orders
WHERE status = 'Completed';

-- =========================================================
-- 5. GROUP BY / ORDER BY
-- =========================================================

-- Q7. Revenue by product.
SELECT
    p.product_name,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Completed'
GROUP BY p.product_id, p.product_name
ORDER BY revenue DESC;

-- Q8. Revenue by category.
SELECT
    c.category_name,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN categories c ON p.category_id = c.category_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Completed'
GROUP BY c.category_id, c.category_name
ORDER BY revenue DESC;

-- =========================================================
-- 6. JOINS
-- =========================================================

-- Q9. Show each completed order with customer details.
SELECT
    o.order_id,
    o.order_date,
    c.customer_name,
    c.city,
    o.status
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.status = 'Completed'
ORDER BY o.order_date;

-- Q10. Show order details with product and category names.
SELECT
    o.order_id,
    o.order_date,
    c.customer_name,
    p.product_name,
    cat.category_name,
    oi.quantity,
    p.unit_price,
    ROUND(oi.quantity * p.unit_price, 2) AS line_total
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
JOIN categories cat ON p.category_id = cat.category_id
WHERE o.status = 'Completed'
ORDER BY o.order_id;

-- =========================================================
-- 7. TOP CUSTOMERS
-- =========================================================

-- Q11. Find top customers by total completed spending.
SELECT
    c.customer_id,
    c.customer_name,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC;

-- Q12. Find customers whose completed spending is above 20,000.
SELECT
    c.customer_name,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.customer_name
HAVING SUM(oi.quantity * p.unit_price) > 20000
ORDER BY total_spent DESC;

-- =========================================================
-- 8. SUBQUERIES
-- =========================================================

-- Q13. Find products priced above the average product price.
SELECT product_name, unit_price
FROM products
WHERE unit_price > (SELECT AVG(unit_price) FROM products)
ORDER BY unit_price DESC;

-- Q14. Find the customer(s) with the highest completed spending.
SELECT
    customer_name,
    total_spent
FROM (
    SELECT
        c.customer_name,
        SUM(oi.quantity * p.unit_price) AS total_spent
    FROM customers c
    JOIN orders o ON c.customer_id = o.customer_id
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    WHERE o.status = 'Completed'
    GROUP BY c.customer_id, c.customer_name
) AS customer_totals
WHERE total_spent = (
    SELECT MAX(total_spent)
    FROM (
        SELECT SUM(oi.quantity * p.unit_price) AS total_spent
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN products p ON oi.product_id = p.product_id
        WHERE o.status = 'Completed'
        GROUP BY o.customer_id
    ) AS totals
);

-- =========================================================
-- 9. CASE STATEMENTS
-- =========================================================

-- Q15. Classify products by price range.
SELECT
    product_name,
    unit_price,
    CASE
        WHEN unit_price >= 30000 THEN 'High Price'
        WHEN unit_price >= 5000 THEN 'Medium Price'
        ELSE 'Low Price'
    END AS price_category
FROM products
ORDER BY unit_price DESC;

-- Q16. Classify customers based on completed spending.
SELECT
    customer_name,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS total_spent,
    CASE
        WHEN SUM(oi.quantity * p.unit_price) >= 50000 THEN 'Premium Customer'
        WHEN SUM(oi.quantity * p.unit_price) >= 20000 THEN 'Regular Customer'
        ELSE 'New/Low Spending Customer'
    END AS customer_segment
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC;

-- =========================================================
-- 10. ADDITIONAL ANALYSIS
-- =========================================================

-- Q17. Monthly revenue.
SELECT
    DATE_FORMAT(o.order_date, '%Y-%m') AS sales_month,
    ROUND(SUM(oi.quantity * p.unit_price), 2) AS monthly_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'Completed'
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY sales_month;

-- Q18. Most frequently purchased products by quantity.
SELECT
    p.product_name,
    SUM(oi.quantity) AS units_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Completed'
GROUP BY p.product_id, p.product_name
ORDER BY units_sold DESC;

-- Q19. Completed vs cancelled order count.
SELECT
    status,
    COUNT(*) AS order_count
FROM orders
GROUP BY status
ORDER BY order_count DESC;

-- Q20. Customers with more than one completed order.
SELECT
    c.customer_name,
    COUNT(o.order_id) AS completed_orders
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.customer_name
HAVING COUNT(o.order_id) > 1
ORDER BY completed_orders DESC;

-- =========================================================
-- END OF WEEK 2 SQL PROJECT
-- =========================================================
