# Week 2: SQL for Data Analysis

## Project: E-Commerce Sales Analysis

This project was created for **Week 2 – SQL for Data Analysis**. It demonstrates practical SQL skills using a small e-commerce database.

### Topics Covered

- `SELECT` and `WHERE`
- `GROUP BY` and `ORDER BY`
- Aggregate functions: `SUM`, `AVG`, `COUNT`
- `JOIN` operations
- Subqueries
- `CASE` statements
- `HAVING`
- Revenue and sales analysis
- Top customer analysis
- Average order value
- Product and category analysis

### Database Structure

The project contains five related tables:

1. **customers** – customer information
2. **categories** – product categories
3. **products** – product names, categories and prices
4. **orders** – customer orders and order status
5. **order_items** – products and quantities included in each order

### Main Analysis Questions

The SQL script answers questions such as:

- What is the total revenue from completed orders?
- What is the average order value?
- Who are the top customers by spending?
- Which product categories generate the most revenue?
- Which products are priced above the average?
- Which products sell the most units?
- How can customers be segmented using `CASE`?
- What is the monthly revenue?
- How many completed and cancelled orders are there?

### How to Run

The script is written for **MySQL 8.0+**.

1. Open MySQL Workbench (or another MySQL-compatible SQL editor).
2. Open `week2_sql_project.sql`.
3. Run the complete script.
4. The script creates the database, tables and sample data automatically.
5. Run the analysis queries and inspect the results.

### GitHub Upload

Recommended repository structure:

```text
week-2-sql-data-analysis/
├── README.md
└── week2_sql_project.sql
```

### Skills Demonstrated

This project demonstrates the ability to create a relational database, insert sample data, retrieve and filter records, perform aggregations, combine tables with joins, use subqueries and apply conditional logic with `CASE`.

**Author:** Your Name  
**Project:** Week 2 – SQL for Data Analysis
